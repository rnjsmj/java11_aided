/**
 * 
 */
/**
 * 
 */
module class_exam {
}